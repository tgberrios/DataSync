--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "DataLake";
--
-- Name: DataLake; Type: DATABASE; Schema: -; Owner: tomy.berrios
--

CREATE DATABASE "DataLake" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "DataLake" OWNER TO "tomy.berrios";

\connect "DataLake"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: metadata; Type: SCHEMA; Schema: -; Owner: tomy.berrios
--

CREATE SCHEMA metadata;


ALTER SCHEMA metadata OWNER TO "tomy.berrios";

--
-- Name: track_processing_changes(); Type: FUNCTION; Schema: metadata; Owner: tomy.berrios
--

CREATE FUNCTION metadata.track_processing_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_record_count BIGINT;
BEGIN
    SELECT COUNT(*) INTO v_record_count
    FROM information_schema.tables
    WHERE table_schema = NEW.schema_name
      AND table_name = NEW.table_name;

    INSERT INTO metadata.processing_log (
        schema_name,
        table_name,
        db_engine,
        status,
        processed_at,
        record_count,
        new_pk
    ) VALUES (
        NEW.schema_name,
        NEW.table_name,
        NEW.db_engine,
        NEW.status,
        NOW(),
        v_record_count,
        NULL
    );

    RETURN NEW;
END;
$$;


ALTER FUNCTION metadata.track_processing_changes() OWNER TO "tomy.berrios";

--
-- Name: update_catalog_timestamp(); Type: FUNCTION; Schema: metadata; Owner: postgres
--

CREATE FUNCTION metadata.update_catalog_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION metadata.update_catalog_timestamp() OWNER TO postgres;

--
-- Name: update_data_governance_timestamp(); Type: FUNCTION; Schema: metadata; Owner: tomy.berrios
--

CREATE FUNCTION metadata.update_data_governance_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    NEW.last_analyzed = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION metadata.update_data_governance_timestamp() OWNER TO "tomy.berrios";

--
-- Name: update_data_quality_timestamp(); Type: FUNCTION; Schema: metadata; Owner: tomy.berrios
--

CREATE FUNCTION metadata.update_data_quality_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION metadata.update_data_quality_timestamp() OWNER TO "tomy.berrios";

--
-- Name: update_transfer_metrics_timestamp(); Type: FUNCTION; Schema: metadata; Owner: tomy.berrios
--

CREATE FUNCTION metadata.update_transfer_metrics_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.created_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION metadata.update_transfer_metrics_timestamp() OWNER TO "tomy.berrios";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alert_rules; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.alert_rules (
    id integer NOT NULL,
    rule_name character varying(200) NOT NULL,
    alert_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    condition_expression text NOT NULL,
    threshold_value character varying(100),
    enabled boolean DEFAULT true,
    notification_channels text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.alert_rules OWNER TO "tomy.berrios";

--
-- Name: alert_rules_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.alert_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.alert_rules_id_seq OWNER TO "tomy.berrios";

--
-- Name: alert_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.alert_rules_id_seq OWNED BY metadata.alert_rules.id;


--
-- Name: alerts; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.alerts (
    id integer NOT NULL,
    alert_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    schema_name character varying(100),
    table_name character varying(100),
    column_name character varying(100),
    source character varying(100),
    status character varying(20) DEFAULT 'OPEN'::character varying,
    assigned_to character varying(200),
    resolved_at timestamp without time zone,
    metadata_json jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.alerts OWNER TO "tomy.berrios";

--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.alerts_id_seq OWNER TO "tomy.berrios";

--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.alerts_id_seq OWNED BY metadata.alerts.id;


--
-- Name: api_catalog; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.api_catalog (
    id integer NOT NULL,
    api_name character varying(255) NOT NULL,
    api_type character varying(50) NOT NULL,
    base_url character varying(500) NOT NULL,
    endpoint character varying(500) NOT NULL,
    http_method character varying(10) DEFAULT 'GET'::character varying NOT NULL,
    auth_type character varying(50) DEFAULT 'NONE'::character varying NOT NULL,
    auth_config jsonb,
    target_db_engine character varying(50) NOT NULL,
    target_connection_string text NOT NULL,
    target_schema character varying(100) NOT NULL,
    target_table character varying(100) NOT NULL,
    request_body text,
    request_headers jsonb,
    query_params jsonb,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    sync_interval integer DEFAULT 3600 NOT NULL,
    last_sync_time timestamp without time zone,
    last_sync_status character varying(50),
    mapping_config jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.api_catalog OWNER TO "tomy.berrios";

--
-- Name: api_catalog_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.api_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.api_catalog_id_seq OWNER TO "tomy.berrios";

--
-- Name: api_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.api_catalog_id_seq OWNED BY metadata.api_catalog.id;


--
-- Name: backup_control_log; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.backup_control_log (
    id integer NOT NULL,
    backup_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    database_name character varying(255) NOT NULL,
    backup_status character varying(20) NOT NULL,
    backup_file_path text,
    backup_size_bytes bigint,
    execution_time_seconds numeric(10,2),
    error_message text
);


ALTER TABLE metadata.backup_control_log OWNER TO "tomy.berrios";

--
-- Name: TABLE backup_control_log; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.backup_control_log IS 'Control log for database backup operations';


--
-- Name: backup_control_log_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.backup_control_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.backup_control_log_id_seq OWNER TO "tomy.berrios";

--
-- Name: backup_control_log_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.backup_control_log_id_seq OWNED BY metadata.backup_control_log.id;


--
-- Name: business_glossary; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.business_glossary (
    id integer NOT NULL,
    term character varying(200) NOT NULL,
    definition text NOT NULL,
    category character varying(100),
    business_domain character varying(100),
    owner character varying(200),
    steward character varying(200),
    related_tables text,
    tags text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.business_glossary OWNER TO "tomy.berrios";

--
-- Name: business_glossary_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.business_glossary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.business_glossary_id_seq OWNER TO "tomy.berrios";

--
-- Name: business_glossary_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.business_glossary_id_seq OWNED BY metadata.business_glossary.id;


--
-- Name: catalog; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.catalog (
    schema_name character varying NOT NULL,
    table_name character varying NOT NULL,
    db_engine character varying NOT NULL,
    connection_string character varying NOT NULL,
    active boolean DEFAULT true,
    status character varying DEFAULT 'full_load'::character varying,
    cluster_name character varying,
    updated_at timestamp without time zone DEFAULT now(),
    pk_columns text,
    pk_strategy character varying(50) DEFAULT 'CDC'::character varying,
    table_size bigint DEFAULT 0,
    notes character varying,
    sync_metadata jsonb DEFAULT '{}'::jsonb,
    mongo_last_sync_time timestamp without time zone
);


ALTER TABLE metadata.catalog OWNER TO "tomy.berrios";

--
-- Name: TABLE catalog; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.catalog IS 'Metadata catalog for all tables managed by DataSync system';


--
-- Name: COLUMN catalog.schema_name; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.schema_name IS 'Database schema name';


--
-- Name: COLUMN catalog.table_name; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.table_name IS 'Table name';


--
-- Name: COLUMN catalog.db_engine; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.db_engine IS 'Source database engine (PostgreSQL, MongoDB, MSSQL, MariaDB)';


--
-- Name: COLUMN catalog.connection_string; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.connection_string IS 'Database connection string';


--
-- Name: COLUMN catalog.active; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.active IS 'Whether the table is actively synchronized';


--
-- Name: COLUMN catalog.status; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.status IS 'Current synchronization status';


--
-- Name: COLUMN catalog.cluster_name; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.cluster_name IS 'Cluster or server name';


--
-- Name: COLUMN catalog.pk_columns; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.pk_columns IS 'JSON array of primary key column names: ["id", "created_at"]';


--
-- Name: COLUMN catalog.pk_strategy; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.pk_strategy IS 'Synchronization strategy: CDC (Change Data Capture) - monitors database changes in real-time using transaction logs';


--
-- Name: COLUMN catalog.table_size; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.table_size IS 'Número aproximado de registros en la tabla para ordenamiento por tamaño';


--
-- Name: COLUMN catalog.notes; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.notes IS 'Additional notes about the table, including error messages or status information';


--
-- Name: COLUMN catalog.sync_metadata; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog.sync_metadata IS 'JSONB field for engine-specific sync metadata (e.g., last_offset for Oracle OFFSET strategy)';


--
-- Name: catalog_locks; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.catalog_locks (
    lock_name character varying(255) NOT NULL,
    acquired_at timestamp without time zone DEFAULT now() NOT NULL,
    acquired_by character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    session_id character varying(255) NOT NULL
);


ALTER TABLE metadata.catalog_locks OWNER TO "tomy.berrios";

--
-- Name: TABLE catalog_locks; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.catalog_locks IS 'Distributed locks for catalog operations to prevent race conditions';


--
-- Name: COLUMN catalog_locks.lock_name; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog_locks.lock_name IS 'Name of the lock (e.g., catalog_sync, catalog_clean)';


--
-- Name: COLUMN catalog_locks.acquired_by; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog_locks.acquired_by IS 'Hostname or instance identifier that acquired the lock';


--
-- Name: COLUMN catalog_locks.expires_at; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog_locks.expires_at IS 'When the lock expires (for automatic cleanup of dead locks)';


--
-- Name: COLUMN catalog_locks.session_id; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.catalog_locks.session_id IS 'Unique session ID to prevent accidental lock release by other instances';


--
-- Name: column_catalog; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.column_catalog (
    id bigint NOT NULL,
    schema_name character varying(255) NOT NULL,
    table_name character varying(255) NOT NULL,
    column_name character varying(255) NOT NULL,
    db_engine character varying(50) NOT NULL,
    connection_string text NOT NULL,
    ordinal_position integer NOT NULL,
    data_type character varying(100) NOT NULL,
    character_maximum_length integer,
    numeric_precision integer,
    numeric_scale integer,
    is_nullable boolean DEFAULT true,
    column_default text,
    column_metadata jsonb,
    is_primary_key boolean DEFAULT false,
    is_foreign_key boolean DEFAULT false,
    is_unique boolean DEFAULT false,
    is_indexed boolean DEFAULT false,
    is_auto_increment boolean DEFAULT false,
    is_generated boolean DEFAULT false,
    null_count bigint,
    null_percentage numeric(5,2),
    distinct_count bigint,
    distinct_percentage numeric(5,2),
    min_value text,
    max_value text,
    avg_value numeric,
    data_category character varying(50),
    sensitivity_level character varying(20),
    contains_pii boolean DEFAULT false,
    contains_phi boolean DEFAULT false,
    first_seen_at timestamp without time zone DEFAULT now(),
    last_seen_at timestamp without time zone DEFAULT now(),
    last_analyzed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    pii_detection_method character varying(50),
    pii_confidence_score numeric(5,2),
    pii_category character varying(50),
    phi_detection_method character varying(50),
    phi_confidence_score numeric(5,2),
    masking_applied boolean DEFAULT false,
    encryption_applied boolean DEFAULT false,
    tokenization_applied boolean DEFAULT false,
    last_pii_scan timestamp without time zone
);


ALTER TABLE metadata.column_catalog OWNER TO "tomy.berrios";

--
-- Name: TABLE column_catalog; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.column_catalog IS 'Catalog of all columns from all database sources with metadata, statistics, and classification';


--
-- Name: COLUMN column_catalog.column_metadata; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.column_catalog.column_metadata IS 'JSONB field containing engine-specific metadata and extended information';


--
-- Name: COLUMN column_catalog.contains_pii; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.column_catalog.contains_pii IS 'Indicates if column contains Personally Identifiable Information';


--
-- Name: COLUMN column_catalog.contains_phi; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.column_catalog.contains_phi IS 'Indicates if column contains Protected Health Information';


--
-- Name: column_catalog_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.column_catalog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.column_catalog_id_seq OWNER TO "tomy.berrios";

--
-- Name: column_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.column_catalog_id_seq OWNED BY metadata.column_catalog.id;


--
-- Name: config; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.config (
    key character varying(100) NOT NULL,
    value text NOT NULL,
    description text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.config OWNER TO "tomy.berrios";

--
-- Name: consent_management; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.consent_management (
    id integer NOT NULL,
    schema_name character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    data_subject_id character varying(200) NOT NULL,
    consent_type character varying(50) NOT NULL,
    consent_status character varying(50) NOT NULL,
    consent_given_at timestamp without time zone,
    consent_withdrawn_at timestamp without time zone,
    legal_basis character varying(100),
    purpose text,
    retention_period character varying(50),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.consent_management OWNER TO "tomy.berrios";

--
-- Name: consent_management_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.consent_management_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.consent_management_id_seq OWNER TO "tomy.berrios";

--
-- Name: consent_management_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.consent_management_id_seq OWNED BY metadata.consent_management.id;


--
-- Name: custom_jobs; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.custom_jobs (
    id integer NOT NULL,
    job_name character varying(255) NOT NULL,
    description text,
    source_db_engine character varying(50) NOT NULL,
    source_connection_string text NOT NULL,
    query_sql text NOT NULL,
    target_db_engine character varying(50) NOT NULL,
    target_connection_string text NOT NULL,
    target_schema character varying(100) NOT NULL,
    target_table character varying(100) NOT NULL,
    schedule_cron character varying(100),
    active boolean DEFAULT true NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    transform_config jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.custom_jobs OWNER TO "tomy.berrios";

--
-- Name: custom_jobs_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.custom_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.custom_jobs_id_seq OWNER TO "tomy.berrios";

--
-- Name: custom_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.custom_jobs_id_seq OWNED BY metadata.custom_jobs.id;


--
-- Name: data_access_log; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_access_log (
    id integer NOT NULL,
    schema_name character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    column_name character varying(100),
    access_type character varying(50) NOT NULL,
    username character varying(100) NOT NULL,
    application_name character varying(200),
    client_addr inet,
    query_text text,
    rows_accessed bigint,
    access_timestamp timestamp without time zone DEFAULT now(),
    is_sensitive_data boolean DEFAULT false,
    masking_applied boolean DEFAULT false,
    compliance_requirement character varying(50)
);


ALTER TABLE metadata.data_access_log OWNER TO "tomy.berrios";

--
-- Name: data_access_log_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_access_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_access_log_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_access_log_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_access_log_id_seq OWNED BY metadata.data_access_log.id;


--
-- Name: data_dictionary; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_dictionary (
    id integer NOT NULL,
    schema_name character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    column_name character varying(100) NOT NULL,
    business_description text,
    business_name character varying(200),
    data_type_business character varying(100),
    business_rules text,
    examples text,
    glossary_term character varying(200),
    owner character varying(200),
    steward character varying(200),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.data_dictionary OWNER TO "tomy.berrios";

--
-- Name: data_dictionary_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_dictionary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_dictionary_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_dictionary_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_dictionary_id_seq OWNED BY metadata.data_dictionary.id;


--
-- Name: data_governance_catalog; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_governance_catalog (
    id integer NOT NULL,
    schema_name character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    total_columns integer,
    total_rows bigint,
    table_size_mb numeric(10,2),
    primary_key_columns character varying(200),
    index_count integer,
    constraint_count integer,
    data_quality_score numeric(10,2),
    null_percentage numeric(10,2),
    duplicate_percentage numeric(10,2),
    inferred_source_engine character varying(50),
    first_discovered timestamp without time zone DEFAULT now(),
    last_analyzed timestamp without time zone,
    last_accessed timestamp without time zone,
    access_frequency character varying(20),
    query_count_daily integer,
    data_category character varying(50),
    business_domain character varying(100),
    sensitivity_level character varying(20),
    health_status character varying(20),
    last_vacuum timestamp without time zone,
    fragmentation_percentage numeric(10,2),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    snapshot_date timestamp without time zone DEFAULT now() NOT NULL,
    data_owner character varying(200),
    data_steward character varying(200),
    data_custodian character varying(200),
    owner_email character varying(200),
    steward_email character varying(200),
    business_glossary_term text,
    data_dictionary_description text,
    approval_required boolean DEFAULT false,
    last_approved_by character varying(200),
    last_approved_at timestamp without time zone,
    encryption_at_rest boolean DEFAULT false,
    encryption_in_transit boolean DEFAULT false,
    masking_policy_applied boolean DEFAULT false,
    masking_policy_name character varying(100),
    row_level_security_enabled boolean DEFAULT false,
    column_level_security_enabled boolean DEFAULT false,
    access_control_policy character varying(200),
    consent_required boolean DEFAULT false,
    consent_type character varying(50),
    legal_basis character varying(100),
    data_subject_rights text,
    cross_border_transfer boolean DEFAULT false,
    cross_border_countries text,
    data_processing_agreement text,
    privacy_impact_assessment text,
    breach_notification_required boolean DEFAULT false,
    last_breach_check timestamp without time zone,
    pii_detection_method character varying(50),
    pii_confidence_score numeric(5,2),
    pii_categories text,
    phi_detection_method character varying(50),
    phi_confidence_score numeric(5,2),
    sensitive_data_count integer DEFAULT 0,
    last_pii_scan timestamp without time zone,
    retention_enforced boolean DEFAULT false,
    archival_policy character varying(100),
    archival_location character varying(200),
    last_archived_at timestamp without time zone,
    legal_hold boolean DEFAULT false,
    legal_hold_reason text,
    legal_hold_until timestamp without time zone,
    data_expiration_date timestamp without time zone,
    auto_delete_enabled boolean DEFAULT false,
    etl_pipeline_name character varying(200),
    etl_pipeline_id character varying(100),
    transformation_rules text,
    source_systems text,
    downstream_systems text,
    bi_tools_used text,
    api_endpoints text,
    quality_sla_score numeric(5,2),
    quality_checks_automated boolean DEFAULT false,
    anomaly_detection_enabled boolean DEFAULT false,
    last_anomaly_detected timestamp without time zone,
    data_freshness_threshold_hours integer,
    last_freshness_check timestamp without time zone,
    schema_evolution_tracking boolean DEFAULT false,
    last_schema_change timestamp without time zone
);


ALTER TABLE metadata.data_governance_catalog OWNER TO "tomy.berrios";

--
-- Name: TABLE data_governance_catalog; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.data_governance_catalog IS 'Comprehensive metadata catalog for all tables in the DataLake';


--
-- Name: COLUMN data_governance_catalog.data_quality_score; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.data_governance_catalog.data_quality_score IS 'Overall data quality score from 0-100';


--
-- Name: COLUMN data_governance_catalog.inferred_source_engine; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.data_governance_catalog.inferred_source_engine IS 'Source database engine inferred from schema patterns';


--
-- Name: COLUMN data_governance_catalog.access_frequency; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.data_governance_catalog.access_frequency IS 'Table access frequency: HIGH (>100 queries/day), MEDIUM (10-100), LOW (<10)';


--
-- Name: COLUMN data_governance_catalog.data_category; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.data_governance_catalog.data_category IS 'Data category: TRANSACTIONAL, ANALYTICAL, REFERENCE';


--
-- Name: COLUMN data_governance_catalog.business_domain; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.data_governance_catalog.business_domain IS 'Business domain classification';


--
-- Name: COLUMN data_governance_catalog.sensitivity_level; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.data_governance_catalog.sensitivity_level IS 'Data sensitivity: LOW, MEDIUM, HIGH';


--
-- Name: COLUMN data_governance_catalog.health_status; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.data_governance_catalog.health_status IS 'Table health status: HEALTHY, WARNING, CRITICAL';


--
-- Name: COLUMN data_governance_catalog.snapshot_date; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.data_governance_catalog.snapshot_date IS 'Timestamp when this snapshot was taken, allows historical tracking of governance metrics';


--
-- Name: data_governance_catalog_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_governance_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_governance_catalog_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_governance_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_governance_catalog_id_seq OWNED BY metadata.data_governance_catalog.id;


--
-- Name: data_governance_catalog_mariadb; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_governance_catalog_mariadb (
    id integer NOT NULL,
    server_name character varying(128) NOT NULL,
    database_name character varying(128) NOT NULL,
    schema_name character varying(128) NOT NULL,
    table_name character varying(256) NOT NULL,
    index_name character varying(256),
    index_columns text,
    index_non_unique boolean,
    index_type character varying(64),
    row_count bigint,
    data_size_mb numeric(18,2),
    index_size_mb numeric(18,2),
    total_size_mb numeric(18,2),
    data_free_mb numeric(18,2),
    fragmentation_pct numeric(6,2),
    engine character varying(64),
    version character varying(64),
    innodb_version character varying(64),
    innodb_page_size integer,
    innodb_file_per_table boolean,
    innodb_flush_log_at_trx_commit integer,
    sync_binlog integer,
    table_reads bigint,
    table_writes bigint,
    index_reads bigint,
    user_total integer,
    user_super_count integer,
    user_locked_count integer,
    user_expired_count integer,
    access_frequency character varying(20),
    health_status character varying(20),
    recommendation_summary text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    snapshot_date timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE metadata.data_governance_catalog_mariadb OWNER TO "tomy.berrios";

--
-- Name: TABLE data_governance_catalog_mariadb; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.data_governance_catalog_mariadb IS 'Governance catalog for MariaDB databases with table and index metrics';


--
-- Name: data_governance_catalog_mariadb_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_governance_catalog_mariadb_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_governance_catalog_mariadb_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_governance_catalog_mariadb_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_governance_catalog_mariadb_id_seq OWNED BY metadata.data_governance_catalog_mariadb.id;


--
-- Name: data_governance_catalog_mongodb; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_governance_catalog_mongodb (
    id integer NOT NULL,
    server_name character varying(128) NOT NULL,
    database_name character varying(128) NOT NULL,
    collection_name character varying(256) NOT NULL,
    index_name character varying(256),
    index_keys text,
    index_unique boolean,
    index_type character varying(64),
    document_count bigint,
    storage_size_mb numeric(18,2),
    index_size_mb numeric(18,2),
    total_size_mb numeric(18,2),
    avg_document_size_bytes bigint,
    storage_engine character varying(64),
    version character varying(64),
    replica_set_name character varying(128),
    sharding_enabled boolean,
    access_frequency character varying(20),
    health_status character varying(20),
    recommendation_summary text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    snapshot_date timestamp without time zone DEFAULT now() NOT NULL,
    index_sparse boolean DEFAULT false,
    collection_size_mb numeric(10,2),
    avg_object_size_bytes numeric(10,2),
    index_count integer,
    is_sharded boolean DEFAULT false,
    shard_key character varying(200),
    health_score numeric(5,2),
    mongodb_version character varying(50)
);


ALTER TABLE metadata.data_governance_catalog_mongodb OWNER TO "tomy.berrios";

--
-- Name: TABLE data_governance_catalog_mongodb; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.data_governance_catalog_mongodb IS 'Governance catalog for MongoDB collections and indexes';


--
-- Name: data_governance_catalog_mongodb_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_governance_catalog_mongodb_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_governance_catalog_mongodb_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_governance_catalog_mongodb_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_governance_catalog_mongodb_id_seq OWNED BY metadata.data_governance_catalog_mongodb.id;


--
-- Name: data_governance_catalog_mssql; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_governance_catalog_mssql (
    id integer NOT NULL,
    server_name character varying(128) NOT NULL,
    database_name character varying(128) NOT NULL,
    schema_name character varying(128) NOT NULL,
    table_name character varying(256),
    object_name character varying(256),
    object_type character varying(64),
    index_name character varying(256),
    index_id integer,
    row_count bigint,
    table_size_mb numeric(18,2),
    fragmentation_pct numeric(6,2),
    page_count bigint,
    fill_factor integer,
    user_seeks bigint,
    user_scans bigint,
    user_lookups bigint,
    user_updates bigint,
    page_splits bigint,
    leaf_inserts bigint,
    index_key_columns text,
    index_include_columns text,
    stats_last_updated timestamp without time zone,
    stats_rows bigint,
    stats_rows_sampled bigint,
    stats_modification_counter bigint,
    has_missing_index boolean,
    missing_index_impact numeric(18,4),
    is_unused boolean,
    is_potential_duplicate boolean,
    last_full_backup timestamp without time zone,
    last_diff_backup timestamp without time zone,
    last_log_backup timestamp without time zone,
    compatibility_level integer,
    recovery_model character varying(32),
    page_verify character varying(32),
    auto_create_stats boolean,
    auto_update_stats boolean,
    auto_update_stats_async boolean,
    data_autogrowth_desc character varying(128),
    log_autogrowth_desc character varying(128),
    maxdop integer,
    cost_threshold integer,
    datafile_size_mb numeric(18,2),
    datafile_free_mb numeric(18,2),
    log_size_mb numeric(18,2),
    log_vlf_count integer,
    sensitivity_label_count integer,
    public_permissions_count integer,
    access_frequency character varying(20),
    health_status character varying(20),
    recommendation_summary text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    server_sysadmin_count integer,
    db_user_count integer,
    db_owner_count integer,
    orphaned_user_count integer,
    guest_has_permissions boolean,
    snapshot_date timestamp without time zone DEFAULT now() NOT NULL,
    missing_index_equality_columns text,
    missing_index_inequality_columns text,
    missing_index_included_columns text,
    missing_index_create_statement text,
    missing_index_avg_user_impact numeric(18,4),
    missing_index_user_seeks bigint,
    missing_index_user_scans bigint,
    missing_index_avg_total_user_cost numeric(18,4),
    missing_index_unique_compiles bigint,
    compatibility_level_desc character varying(50),
    object_category character varying(32),
    object_id bigint,
    health_score numeric(5,2),
    definition_hash character(40),
    created_at_db timestamp without time zone,
    modified_at_db timestamp without time zone,
    uses_execute_as boolean,
    uses_recompile_hint boolean,
    uses_maxdop_hint boolean,
    uses_force_order_hint boolean,
    uses_parallel_hint boolean,
    uses_force_plan_hint boolean,
    compatibility_legacy_ce boolean,
    total_elapsed_ms numeric(18,2),
    avg_elapsed_ms numeric(18,2),
    max_elapsed_ms numeric(18,2),
    total_cpu_ms numeric(18,2),
    total_logical_reads bigint,
    total_logical_writes bigint,
    total_physical_reads bigint,
    last_execution_at timestamp without time zone,
    is_top_slow boolean,
    is_top_cpu boolean,
    is_top_io boolean,
    is_top_fast boolean,
    suggestion_summary text,
    suggestion_detail text,
    execution_count bigint,
    stats_status character varying(20),
    full_backup_status character varying(20),
    priority character varying(20),
    column_name character varying(256),
    check_type character varying(64),
    checked_rows bigint,
    issue_count bigint,
    metric_value numeric(18,6),
    threshold numeric(18,6),
    severity character varying(16),
    status character varying(16),
    recommendation text,
    details text,
    observed_at timestamp without time zone,
    sp_name character varying(256),
    avg_execution_time_seconds numeric(18,4),
    total_elapsed_time_ms bigint,
    avg_logical_reads bigint,
    avg_physical_reads bigint,
    previous_avg_time numeric(18,4),
    current_avg_time numeric(18,4),
    increase_pct numeric(18,4),
    alert_level character varying(20),
    execution_time numeric(18,4),
    cpu_time numeric(18,4),
    logical_reads bigint,
    physical_reads bigint,
    timeout_count_5min integer
);


ALTER TABLE metadata.data_governance_catalog_mssql OWNER TO "tomy.berrios";

--
-- Name: TABLE data_governance_catalog_mssql; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.data_governance_catalog_mssql IS 'Unified governance catalog for MSSQL including tables, indexes, stored procedures, data quality results, and execution alerts';


--
-- Name: data_governance_catalog_mssql_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_governance_catalog_mssql_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_governance_catalog_mssql_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_governance_catalog_mssql_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_governance_catalog_mssql_id_seq OWNED BY metadata.data_governance_catalog_mssql.id;


--
-- Name: data_governance_catalog_oracle; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_governance_catalog_oracle (
    id integer NOT NULL,
    server_name character varying(200) NOT NULL,
    schema_name character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    index_name character varying(200),
    index_columns text,
    index_unique boolean DEFAULT false,
    index_type character varying(50),
    row_count bigint,
    table_size_mb numeric(10,2),
    index_size_mb numeric(10,2),
    total_size_mb numeric(10,2),
    data_free_mb numeric(10,2),
    fragmentation_pct numeric(5,2),
    tablespace_name character varying(100),
    version character varying(100),
    block_size integer,
    num_rows bigint,
    blocks bigint,
    empty_blocks bigint,
    avg_row_len bigint,
    chain_cnt bigint,
    avg_space bigint,
    compression character varying(50),
    logging character varying(10),
    partitioned character varying(10),
    iot_type character varying(50),
    temporary character varying(10),
    access_frequency character varying(20),
    health_status character varying(20),
    recommendation_summary text,
    health_score numeric(5,2),
    snapshot_date timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.data_governance_catalog_oracle OWNER TO "tomy.berrios";

--
-- Name: data_governance_catalog_oracle_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_governance_catalog_oracle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_governance_catalog_oracle_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_governance_catalog_oracle_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_governance_catalog_oracle_id_seq OWNED BY metadata.data_governance_catalog_oracle.id;


--
-- Name: data_quality; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_quality (
    id bigint NOT NULL,
    schema_name character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    source_db_engine character varying(50) NOT NULL,
    check_timestamp timestamp without time zone DEFAULT now() NOT NULL,
    total_rows bigint DEFAULT 0 NOT NULL,
    null_count bigint DEFAULT 0 NOT NULL,
    duplicate_count bigint DEFAULT 0 NOT NULL,
    data_checksum character varying(64),
    invalid_type_count bigint DEFAULT 0 NOT NULL,
    type_mismatch_details jsonb,
    out_of_range_count bigint DEFAULT 0 NOT NULL,
    referential_integrity_errors bigint DEFAULT 0 NOT NULL,
    constraint_violation_count bigint DEFAULT 0 NOT NULL,
    integrity_check_details jsonb,
    validation_status character varying(20) NOT NULL,
    error_details text,
    quality_score numeric(5,2),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    check_duration_ms bigint DEFAULT 0 NOT NULL,
    CONSTRAINT data_quality_quality_score_check CHECK (((quality_score >= (0)::numeric) AND (quality_score <= (100)::numeric))),
    CONSTRAINT data_quality_validation_status_check CHECK (((validation_status)::text = ANY ((ARRAY['PASSED'::character varying, 'FAILED'::character varying, 'WARNING'::character varying])::text[])))
);


ALTER TABLE metadata.data_quality OWNER TO "tomy.berrios";

--
-- Name: TABLE data_quality; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.data_quality IS 'Stores data quality metrics and validation results for synchronized tables';


--
-- Name: data_quality_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_quality_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_quality_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_quality_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_quality_id_seq OWNED BY metadata.data_quality.id;


--
-- Name: data_quality_rules; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_quality_rules (
    id integer NOT NULL,
    rule_name character varying(200) NOT NULL,
    schema_name character varying(100),
    table_name character varying(100),
    column_name character varying(100),
    rule_type character varying(50) NOT NULL,
    rule_definition text NOT NULL,
    severity character varying(20) DEFAULT 'WARNING'::character varying,
    enabled boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.data_quality_rules OWNER TO "tomy.berrios";

--
-- Name: data_quality_rules_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_quality_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_quality_rules_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_quality_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_quality_rules_id_seq OWNED BY metadata.data_quality_rules.id;


--
-- Name: data_retention_jobs; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_retention_jobs (
    id integer NOT NULL,
    schema_name character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    job_type character varying(50) NOT NULL,
    retention_policy character varying(50),
    scheduled_date timestamp without time zone,
    executed_at timestamp without time zone,
    status character varying(50) DEFAULT 'PENDING'::character varying,
    rows_affected bigint,
    error_message text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.data_retention_jobs OWNER TO "tomy.berrios";

--
-- Name: data_retention_jobs_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_retention_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_retention_jobs_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_retention_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_retention_jobs_id_seq OWNED BY metadata.data_retention_jobs.id;


--
-- Name: data_subject_requests; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.data_subject_requests (
    id integer NOT NULL,
    request_id character varying(100) NOT NULL,
    request_type character varying(50) NOT NULL,
    data_subject_email character varying(200),
    data_subject_name character varying(200),
    request_status character varying(50) DEFAULT 'PENDING'::character varying,
    requested_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    requested_data text,
    response_data text,
    processed_by character varying(200),
    notes text,
    compliance_requirement character varying(50)
);


ALTER TABLE metadata.data_subject_requests OWNER TO "tomy.berrios";

--
-- Name: data_subject_requests_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.data_subject_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.data_subject_requests_id_seq OWNER TO "tomy.berrios";

--
-- Name: data_subject_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.data_subject_requests_id_seq OWNED BY metadata.data_subject_requests.id;


--
-- Name: job_results; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.job_results (
    id integer NOT NULL,
    job_name character varying(255) NOT NULL,
    process_log_id bigint,
    row_count bigint DEFAULT 0 NOT NULL,
    result_sample jsonb,
    full_result_stored boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.job_results OWNER TO "tomy.berrios";

--
-- Name: job_results_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.job_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.job_results_id_seq OWNER TO "tomy.berrios";

--
-- Name: job_results_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.job_results_id_seq OWNED BY metadata.job_results.id;


--
-- Name: logs; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.logs (
    ts timestamp with time zone NOT NULL,
    level text NOT NULL,
    category text NOT NULL,
    function text,
    message text NOT NULL
);


ALTER TABLE metadata.logs OWNER TO "tomy.berrios";

--
-- Name: maintenance_control; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.maintenance_control (
    id integer NOT NULL,
    maintenance_type character varying(50) NOT NULL,
    schema_name character varying(255) NOT NULL,
    object_name character varying(255) NOT NULL,
    object_type character varying(50) NOT NULL,
    metric_before jsonb,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    priority integer,
    last_maintenance_date timestamp without time zone,
    next_maintenance_date timestamp without time zone,
    maintenance_duration_seconds double precision,
    maintenance_count integer DEFAULT 0,
    first_detected_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_checked_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    result_message text,
    error_details text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    db_engine character varying(50),
    connection_string text,
    auto_execute boolean DEFAULT true,
    enabled boolean DEFAULT true,
    thresholds jsonb,
    maintenance_schedule jsonb,
    metrics_before jsonb,
    metrics_after jsonb,
    space_reclaimed_mb double precision DEFAULT 0,
    performance_improvement_pct double precision DEFAULT 0,
    fragmentation_before double precision,
    fragmentation_after double precision,
    dead_tuples_before bigint,
    dead_tuples_after bigint,
    index_size_before_mb double precision,
    index_size_after_mb double precision,
    table_size_before_mb double precision,
    table_size_after_mb double precision,
    query_performance_before double precision,
    query_performance_after double precision,
    impact_score double precision GENERATED ALWAYS AS (
CASE
    WHEN ((space_reclaimed_mb > (0)::double precision) OR (performance_improvement_pct > (0)::double precision)) THEN ((((COALESCE(space_reclaimed_mb, (0)::double precision) / (100.0)::double precision) * (0.4)::double precision) + ((COALESCE(performance_improvement_pct, (0)::double precision) / (10.0)::double precision) * (0.4)::double precision)) + (
    CASE
        WHEN ((fragmentation_before IS NOT NULL) AND (fragmentation_after IS NOT NULL)) THEN ((fragmentation_before - fragmentation_after) / (10.0)::double precision)
        ELSE (0)::double precision
    END * (0.2)::double precision))
    ELSE (0)::double precision
END) STORED,
    server_name character varying(255),
    database_name character varying(255)
);


ALTER TABLE metadata.maintenance_control OWNER TO "tomy.berrios";

--
-- Name: TABLE maintenance_control; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.maintenance_control IS 'Control table for maintenance operations on tables and indexes';


--
-- Name: COLUMN maintenance_control.db_engine; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.db_engine IS 'Database engine: PostgreSQL, MariaDB, or MSSQL';


--
-- Name: COLUMN maintenance_control.connection_string; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.connection_string IS 'Connection string to the source database';


--
-- Name: COLUMN maintenance_control.auto_execute; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.auto_execute IS 'If true, maintenance executes automatically. If false, manual execution only';


--
-- Name: COLUMN maintenance_control.enabled; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.enabled IS 'If false, maintenance is disabled for this object';


--
-- Name: COLUMN maintenance_control.thresholds; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.thresholds IS 'JSON configuration of detection thresholds';


--
-- Name: COLUMN maintenance_control.maintenance_schedule; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.maintenance_schedule IS 'JSON configuration of maintenance schedule';


--
-- Name: COLUMN maintenance_control.space_reclaimed_mb; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.space_reclaimed_mb IS 'Space reclaimed in MB after maintenance';


--
-- Name: COLUMN maintenance_control.performance_improvement_pct; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.performance_improvement_pct IS 'Performance improvement percentage';


--
-- Name: COLUMN maintenance_control.impact_score; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.impact_score IS 'Calculated impact score (0-100) based on space reclaimed, performance improvement, and fragmentation reduction';


--
-- Name: COLUMN maintenance_control.server_name; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.server_name IS 'Server name (mainly for MSSQL compatibility)';


--
-- Name: COLUMN maintenance_control.database_name; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_control.database_name IS 'Database name (mainly for MSSQL compatibility)';


--
-- Name: maintenance_control_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.maintenance_control_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.maintenance_control_id_seq OWNER TO "tomy.berrios";

--
-- Name: maintenance_control_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.maintenance_control_id_seq OWNED BY metadata.maintenance_control.id;


--
-- Name: maintenance_metrics; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.maintenance_metrics (
    id integer NOT NULL,
    execution_date date NOT NULL,
    maintenance_type character varying(50) NOT NULL,
    total_detected integer DEFAULT 0,
    total_fixed integer DEFAULT 0,
    total_failed integer DEFAULT 0,
    total_skipped integer DEFAULT 0,
    total_duration_seconds double precision,
    avg_duration_per_object double precision,
    space_reclaimed_mb double precision,
    objects_improved integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    server_name character varying(255),
    db_engine character varying(50)
);


ALTER TABLE metadata.maintenance_metrics OWNER TO "tomy.berrios";

--
-- Name: TABLE maintenance_metrics; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.maintenance_metrics IS 'Aggregated metrics for maintenance operations';


--
-- Name: COLUMN maintenance_metrics.server_name; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_metrics.server_name IS 'Server name (mainly for MSSQL compatibility)';


--
-- Name: COLUMN maintenance_metrics.db_engine; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.maintenance_metrics.db_engine IS 'Database engine: PostgreSQL, MariaDB, or MSSQL';


--
-- Name: maintenance_metrics_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.maintenance_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.maintenance_metrics_id_seq OWNER TO "tomy.berrios";

--
-- Name: maintenance_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.maintenance_metrics_id_seq OWNED BY metadata.maintenance_metrics.id;


--
-- Name: mdb_lineage; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.mdb_lineage (
    id bigint NOT NULL,
    server_name character varying(128) NOT NULL,
    database_name character varying(128),
    schema_name character varying(128),
    object_name character varying(256) NOT NULL,
    object_type character varying(32) NOT NULL,
    column_name character varying(256),
    target_object_name character varying(256),
    target_object_type character varying(32),
    target_column_name text,
    relationship_type character varying(32) NOT NULL,
    definition_text text,
    discovery_method character varying(64) NOT NULL,
    discovered_by character varying(64) NOT NULL,
    confidence_score numeric(5,4) DEFAULT 1.0000 NOT NULL,
    first_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    consumer_type character varying(64),
    consumer_name character varying(256),
    consumer_context text,
    edge_key text NOT NULL,
    dependency_level integer DEFAULT 1
);


ALTER TABLE metadata.mdb_lineage OWNER TO "tomy.berrios";

--
-- Name: TABLE mdb_lineage; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.mdb_lineage IS 'Data lineage for MariaDB objects and dependencies';


--
-- Name: mdb_lineage_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.mdb_lineage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.mdb_lineage_id_seq OWNER TO "tomy.berrios";

--
-- Name: mdb_lineage_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.mdb_lineage_id_seq OWNED BY metadata.mdb_lineage.id;


--
-- Name: mongo_lineage; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.mongo_lineage (
    id bigint NOT NULL,
    server_name character varying(128) NOT NULL,
    database_name character varying(128),
    schema_name character varying(128),
    object_name character varying(256) NOT NULL,
    object_type character varying(32) NOT NULL,
    column_name character varying(256),
    target_object_name character varying(256),
    target_object_type character varying(32),
    target_column_name text,
    relationship_type character varying(32) NOT NULL,
    definition_text text,
    discovery_method character varying(64) NOT NULL,
    discovered_by character varying(64) NOT NULL,
    confidence_score numeric(5,4) DEFAULT 1.0000 NOT NULL,
    first_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    consumer_type character varying(64),
    consumer_name character varying(256),
    consumer_context text,
    edge_key text NOT NULL,
    source_collection character varying(100) NOT NULL,
    source_field character varying(100),
    target_collection character varying(100),
    target_field character varying(100),
    dependency_level integer DEFAULT 1,
    snapshot_date timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.mongo_lineage OWNER TO "tomy.berrios";

--
-- Name: TABLE mongo_lineage; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.mongo_lineage IS 'Data lineage for MongoDB collections and dependencies';


--
-- Name: mongo_lineage_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.mongo_lineage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.mongo_lineage_id_seq OWNER TO "tomy.berrios";

--
-- Name: mongo_lineage_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.mongo_lineage_id_seq OWNED BY metadata.mongo_lineage.id;


--
-- Name: mssql_lineage; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.mssql_lineage (
    id bigint NOT NULL,
    edge_key text NOT NULL,
    server_name character varying(128) NOT NULL,
    instance_name character varying(128),
    database_name character varying(128),
    schema_name character varying(128),
    object_name character varying(256) NOT NULL,
    object_type character varying(32) NOT NULL,
    column_name character varying(256),
    source_query_hash character varying(64),
    source_query_plan xml,
    target_object_name character varying(256),
    target_object_type character varying(32),
    target_column_name character varying(256),
    relationship_type character varying(32) NOT NULL,
    definition_text text,
    dependency_level integer,
    discovery_method character varying(64) NOT NULL,
    discovered_by character varying(64) NOT NULL,
    confidence_score numeric(5,4) DEFAULT 1.0000 NOT NULL,
    first_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    execution_count bigint,
    last_execution_at timestamp without time zone,
    avg_duration_ms numeric(12,4),
    avg_cpu_ms numeric(12,4),
    avg_logical_reads bigint,
    avg_physical_reads bigint,
    consumer_type character varying(64),
    consumer_name character varying(256),
    consumer_context text,
    tags text[]
);


ALTER TABLE metadata.mssql_lineage OWNER TO "tomy.berrios";

--
-- Name: TABLE mssql_lineage; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.mssql_lineage IS 'Data lineage for MSSQL objects, stored procedures, and dependencies';


--
-- Name: mssql_lineage_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.mssql_lineage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.mssql_lineage_id_seq OWNER TO "tomy.berrios";

--
-- Name: mssql_lineage_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.mssql_lineage_id_seq OWNED BY metadata.mssql_lineage.id;


--
-- Name: oracle_lineage; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.oracle_lineage (
    id integer NOT NULL,
    edge_key character varying(500) NOT NULL,
    server_name character varying(200) NOT NULL,
    schema_name character varying(100) NOT NULL,
    object_name character varying(100) NOT NULL,
    object_type character varying(50) NOT NULL,
    column_name character varying(100),
    target_object_name character varying(100),
    target_object_type character varying(50),
    target_column_name character varying(100),
    relationship_type character varying(50) NOT NULL,
    definition_text text,
    dependency_level integer DEFAULT 1,
    discovery_method character varying(50),
    discovered_by character varying(100),
    confidence_score numeric(3,2) DEFAULT 1.0,
    first_seen_at timestamp without time zone DEFAULT now(),
    last_seen_at timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.oracle_lineage OWNER TO "tomy.berrios";

--
-- Name: oracle_lineage_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.oracle_lineage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.oracle_lineage_id_seq OWNER TO "tomy.berrios";

--
-- Name: oracle_lineage_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.oracle_lineage_id_seq OWNED BY metadata.oracle_lineage.id;


--
-- Name: process_log; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.process_log (
    id bigint NOT NULL,
    process_type character varying(50) NOT NULL,
    process_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    duration_seconds integer,
    source_schema character varying(100),
    target_schema character varying(100),
    tables_processed integer DEFAULT 0,
    total_rows_processed bigint DEFAULT 0,
    tables_success integer DEFAULT 0,
    tables_failed integer DEFAULT 0,
    tables_skipped integer DEFAULT 0,
    error_message text,
    warning_message text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE metadata.process_log OWNER TO "tomy.berrios";

--
-- Name: TABLE process_log; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.process_log IS 'General logging table for ETL processes, maintenance and jobs';


--
-- Name: COLUMN process_log.process_type; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.process_log.process_type IS 'ETL, MAINTENANCE, BACKUP, RESTORE, etc.';


--
-- Name: COLUMN process_log.process_name; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.process_log.process_name IS 'Process/job/DAG name';


--
-- Name: COLUMN process_log.status; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.process_log.status IS 'SUCCESS, ERROR, IN_PROGRESS, WARNING, SKIPPED';


--
-- Name: process_log_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.process_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.process_log_id_seq OWNER TO "tomy.berrios";

--
-- Name: process_log_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.process_log_id_seq OWNED BY metadata.process_log.id;


--
-- Name: processing_log; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.processing_log (
    id integer NOT NULL,
    schema_name character varying NOT NULL,
    table_name character varying NOT NULL,
    db_engine character varying NOT NULL,
    new_pk text,
    status character varying,
    processed_at timestamp without time zone DEFAULT now(),
    record_count bigint
);


ALTER TABLE metadata.processing_log OWNER TO "tomy.berrios";

--
-- Name: processing_log_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.processing_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.processing_log_id_seq OWNER TO "tomy.berrios";

--
-- Name: processing_log_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.processing_log_id_seq OWNED BY metadata.processing_log.id;


--
-- Name: query_performance; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.query_performance (
    id bigint NOT NULL,
    captured_at timestamp without time zone DEFAULT now() NOT NULL,
    source_type text NOT NULL,
    pid integer,
    dbname text,
    username text,
    application_name text,
    client_addr inet,
    queryid bigint,
    query_text text NOT NULL,
    query_fingerprint text,
    state text,
    wait_event_type text,
    wait_event text,
    calls bigint,
    total_time_ms double precision,
    mean_time_ms double precision,
    min_time_ms double precision,
    max_time_ms double precision,
    query_duration_ms double precision,
    rows_returned bigint,
    estimated_rows bigint,
    shared_blks_hit bigint,
    shared_blks_read bigint,
    shared_blks_dirtied bigint,
    shared_blks_written bigint,
    local_blks_hit bigint,
    local_blks_read bigint,
    local_blks_dirtied bigint,
    local_blks_written bigint,
    temp_blks_read bigint,
    temp_blks_written bigint,
    blk_read_time_ms double precision,
    blk_write_time_ms double precision,
    wal_records bigint,
    wal_fpi bigint,
    wal_bytes numeric,
    operation_type text,
    query_category text,
    tables_count integer,
    has_joins boolean DEFAULT false,
    has_subqueries boolean DEFAULT false,
    has_cte boolean DEFAULT false,
    has_window_functions boolean DEFAULT false,
    has_functions boolean DEFAULT false,
    is_prepared boolean DEFAULT false,
    plan_available boolean DEFAULT false,
    estimated_cost double precision,
    execution_plan_hash text,
    cache_hit_ratio double precision GENERATED ALWAYS AS (
CASE
    WHEN ((shared_blks_hit + shared_blks_read) > 0) THEN (((shared_blks_hit)::double precision * (100.0)::double precision) / ((shared_blks_hit + shared_blks_read))::double precision)
    ELSE NULL::double precision
END) STORED,
    io_efficiency double precision GENERATED ALWAYS AS (
CASE
    WHEN ((total_time_ms > (0)::double precision) AND ((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written) > 0)) THEN (((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written))::double precision / total_time_ms)
    WHEN ((query_duration_ms > (0)::double precision) AND ((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written) > 0)) THEN (((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written))::double precision / query_duration_ms)
    ELSE NULL::double precision
END) STORED,
    query_efficiency_score double precision GENERATED ALWAYS AS (
CASE
    WHEN (source_type = 'snapshot'::text) THEN ((((
    CASE
        WHEN (mean_time_ms < (100)::double precision) THEN 100.0
        WHEN (mean_time_ms < (1000)::double precision) THEN 80.0
        WHEN (mean_time_ms < (5000)::double precision) THEN 60.0
        ELSE 40.0
    END * 0.4))::double precision + (
    CASE
        WHEN ((shared_blks_hit + shared_blks_read) > 0) THEN (((shared_blks_hit)::double precision * (100.0)::double precision) / ((shared_blks_hit + shared_blks_read))::double precision)
        ELSE (50.0)::double precision
    END * (0.4)::double precision)) + (
    CASE
        WHEN ((total_time_ms > (0)::double precision) AND ((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written) > 0)) THEN LEAST((100.0)::double precision, ((100.0)::double precision / (((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written))::double precision / total_time_ms)))
        ELSE (50.0)::double precision
    END * (0.2)::double precision))
    WHEN (source_type = 'activity'::text) THEN ((((
    CASE
        WHEN (query_duration_ms < (1000)::double precision) THEN 100.0
        WHEN (query_duration_ms < (5000)::double precision) THEN 80.0
        WHEN (query_duration_ms < (30000)::double precision) THEN 60.0
        ELSE 40.0
    END * 0.5) + (
    CASE
        WHEN (state = 'active'::text) THEN 100.0
        ELSE 60.0
    END * 0.3)) + (
    CASE
        WHEN ((wait_event_type IS NOT NULL) AND (wait_event_type <> 'ClientRead'::text)) THEN 40.0
        ELSE 100.0
    END * 0.2)))::double precision
    ELSE (50.0)::double precision
END) STORED,
    is_long_running boolean GENERATED ALWAYS AS (
CASE
    WHEN ((source_type = 'activity'::text) AND (query_duration_ms > (60000)::double precision)) THEN true
    WHEN ((source_type = 'snapshot'::text) AND (mean_time_ms > (5000)::double precision)) THEN true
    ELSE false
END) STORED,
    is_blocking boolean GENERATED ALWAYS AS (
CASE
    WHEN ((source_type = 'activity'::text) AND (wait_event_type IS NOT NULL) AND (wait_event_type <> 'ClientRead'::text) AND (wait_event_type <> ''::text)) THEN true
    ELSE false
END) STORED,
    performance_tier text GENERATED ALWAYS AS (
CASE
    WHEN (source_type = 'snapshot'::text) THEN
    CASE
        WHEN (((((
        CASE
            WHEN (mean_time_ms < (100)::double precision) THEN 100.0
            WHEN (mean_time_ms < (1000)::double precision) THEN 80.0
            WHEN (mean_time_ms < (5000)::double precision) THEN 60.0
            ELSE 40.0
        END * 0.4))::double precision + (
        CASE
            WHEN ((shared_blks_hit + shared_blks_read) > 0) THEN (((shared_blks_hit)::double precision * (100.0)::double precision) / ((shared_blks_hit + shared_blks_read))::double precision)
            ELSE (50.0)::double precision
        END * (0.4)::double precision)) + (
        CASE
            WHEN ((total_time_ms > (0)::double precision) AND ((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written) > 0)) THEN LEAST((100.0)::double precision, ((100.0)::double precision / (((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written))::double precision / total_time_ms)))
            ELSE (50.0)::double precision
        END * (0.2)::double precision)) >= (80)::double precision) THEN 'EXCELLENT'::text
        WHEN (((((
        CASE
            WHEN (mean_time_ms < (100)::double precision) THEN 100.0
            WHEN (mean_time_ms < (1000)::double precision) THEN 80.0
            WHEN (mean_time_ms < (5000)::double precision) THEN 60.0
            ELSE 40.0
        END * 0.4))::double precision + (
        CASE
            WHEN ((shared_blks_hit + shared_blks_read) > 0) THEN (((shared_blks_hit)::double precision * (100.0)::double precision) / ((shared_blks_hit + shared_blks_read))::double precision)
            ELSE (50.0)::double precision
        END * (0.4)::double precision)) + (
        CASE
            WHEN ((total_time_ms > (0)::double precision) AND ((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written) > 0)) THEN LEAST((100.0)::double precision, ((100.0)::double precision / (((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written))::double precision / total_time_ms)))
            ELSE (50.0)::double precision
        END * (0.2)::double precision)) >= (60)::double precision) THEN 'GOOD'::text
        WHEN (((((
        CASE
            WHEN (mean_time_ms < (100)::double precision) THEN 100.0
            WHEN (mean_time_ms < (1000)::double precision) THEN 80.0
            WHEN (mean_time_ms < (5000)::double precision) THEN 60.0
            ELSE 40.0
        END * 0.4))::double precision + (
        CASE
            WHEN ((shared_blks_hit + shared_blks_read) > 0) THEN (((shared_blks_hit)::double precision * (100.0)::double precision) / ((shared_blks_hit + shared_blks_read))::double precision)
            ELSE (50.0)::double precision
        END * (0.4)::double precision)) + (
        CASE
            WHEN ((total_time_ms > (0)::double precision) AND ((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written) > 0)) THEN LEAST((100.0)::double precision, ((100.0)::double precision / (((((shared_blks_read + temp_blks_read) + shared_blks_written) + temp_blks_written))::double precision / total_time_ms)))
            ELSE (50.0)::double precision
        END * (0.2)::double precision)) >= (40)::double precision) THEN 'FAIR'::text
        ELSE 'POOR'::text
    END
    WHEN (source_type = 'activity'::text) THEN
    CASE
        WHEN ((((
        CASE
            WHEN (query_duration_ms < (1000)::double precision) THEN 100.0
            WHEN (query_duration_ms < (5000)::double precision) THEN 80.0
            WHEN (query_duration_ms < (30000)::double precision) THEN 60.0
            ELSE 40.0
        END * 0.5) + (
        CASE
            WHEN (state = 'active'::text) THEN 100.0
            ELSE 60.0
        END * 0.3)) + (
        CASE
            WHEN ((wait_event_type IS NOT NULL) AND (wait_event_type <> 'ClientRead'::text)) THEN 40.0
            ELSE 100.0
        END * 0.2)) >= (80)::numeric) THEN 'EXCELLENT'::text
        WHEN ((((
        CASE
            WHEN (query_duration_ms < (1000)::double precision) THEN 100.0
            WHEN (query_duration_ms < (5000)::double precision) THEN 80.0
            WHEN (query_duration_ms < (30000)::double precision) THEN 60.0
            ELSE 40.0
        END * 0.5) + (
        CASE
            WHEN (state = 'active'::text) THEN 100.0
            ELSE 60.0
        END * 0.3)) + (
        CASE
            WHEN ((wait_event_type IS NOT NULL) AND (wait_event_type <> 'ClientRead'::text)) THEN 40.0
            ELSE 100.0
        END * 0.2)) >= (60)::numeric) THEN 'GOOD'::text
        WHEN ((((
        CASE
            WHEN (query_duration_ms < (1000)::double precision) THEN 100.0
            WHEN (query_duration_ms < (5000)::double precision) THEN 80.0
            WHEN (query_duration_ms < (30000)::double precision) THEN 60.0
            ELSE 40.0
        END * 0.5) + (
        CASE
            WHEN (state = 'active'::text) THEN 100.0
            ELSE 60.0
        END * 0.3)) + (
        CASE
            WHEN ((wait_event_type IS NOT NULL) AND (wait_event_type <> 'ClientRead'::text)) THEN 40.0
            ELSE 100.0
        END * 0.2)) >= (40)::numeric) THEN 'FAIR'::text
        ELSE 'POOR'::text
    END
    ELSE 'FAIR'::text
END) STORED,
    CONSTRAINT query_performance_source_type_check CHECK ((source_type = ANY (ARRAY['snapshot'::text, 'activity'::text])))
);


ALTER TABLE metadata.query_performance OWNER TO "tomy.berrios";

--
-- Name: TABLE query_performance; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.query_performance IS 'Unified table for query performance monitoring combining snapshots from pg_stat_statements and active queries from pg_stat_activity';


--
-- Name: COLUMN query_performance.source_type; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.query_performance.source_type IS 'Type of source: snapshot (from pg_stat_statements) or activity (from pg_stat_activity)';


--
-- Name: COLUMN query_performance.cache_hit_ratio; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.query_performance.cache_hit_ratio IS 'Calculated cache hit ratio percentage';


--
-- Name: COLUMN query_performance.io_efficiency; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.query_performance.io_efficiency IS 'Calculated IO efficiency metric';


--
-- Name: COLUMN query_performance.query_efficiency_score; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.query_performance.query_efficiency_score IS 'Calculated overall query efficiency score (0-100)';


--
-- Name: COLUMN query_performance.is_long_running; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.query_performance.is_long_running IS 'Indicates if query is long-running';


--
-- Name: COLUMN query_performance.is_blocking; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.query_performance.is_blocking IS 'Indicates if query is blocking other queries';


--
-- Name: COLUMN query_performance.performance_tier; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.query_performance.performance_tier IS 'Performance tier: EXCELLENT, GOOD, FAIR, or POOR';


--
-- Name: query_performance_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.query_performance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.query_performance_id_seq OWNER TO "tomy.berrios";

--
-- Name: query_performance_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.query_performance_id_seq OWNED BY metadata.query_performance.id;


--
-- Name: system_logs; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.system_logs (
    id integer NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    cpu_usage numeric(5,2) NOT NULL,
    cpu_cores integer NOT NULL,
    memory_used_gb numeric(10,2) NOT NULL,
    memory_total_gb numeric(10,2) NOT NULL,
    memory_percentage numeric(5,2) NOT NULL,
    memory_rss_gb numeric(10,2),
    memory_virtual_gb numeric(10,2),
    network_iops numeric(10,2),
    throughput_rps numeric(10,2),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE metadata.system_logs OWNER TO "tomy.berrios";

--
-- Name: TABLE system_logs; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.system_logs IS 'Stores historical system resource metrics for monitoring and analysis';


--
-- Name: system_logs_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.system_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.system_logs_id_seq OWNER TO "tomy.berrios";

--
-- Name: system_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.system_logs_id_seq OWNED BY metadata.system_logs.id;


--
-- Name: transfer_metrics; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.transfer_metrics (
    id integer NOT NULL,
    schema_name character varying(100) NOT NULL,
    table_name character varying(100) NOT NULL,
    db_engine character varying(50) NOT NULL,
    records_transferred bigint,
    bytes_transferred bigint,
    memory_used_mb numeric(20,2),
    io_operations_per_second integer,
    transfer_type character varying(20),
    status character varying(20),
    error_message text,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    created_date date GENERATED ALWAYS AS ((created_at)::date) STORED
);


ALTER TABLE metadata.transfer_metrics OWNER TO "tomy.berrios";

--
-- Name: TABLE transfer_metrics; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON TABLE metadata.transfer_metrics IS 'Real database metrics for data transfer operations';


--
-- Name: COLUMN transfer_metrics.records_transferred; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.transfer_metrics.records_transferred IS 'Current live tuples in the table';


--
-- Name: COLUMN transfer_metrics.bytes_transferred; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.transfer_metrics.bytes_transferred IS 'Actual table size in bytes';


--
-- Name: COLUMN transfer_metrics.memory_used_mb; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.transfer_metrics.memory_used_mb IS 'Table size in MB';


--
-- Name: COLUMN transfer_metrics.io_operations_per_second; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.transfer_metrics.io_operations_per_second IS 'Total database operations (inserts + updates + deletes)';


--
-- Name: COLUMN transfer_metrics.transfer_type; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.transfer_metrics.transfer_type IS 'Type of transfer: FULL_LOAD, INCREMENTAL, SYNC';


--
-- Name: COLUMN transfer_metrics.status; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.transfer_metrics.status IS 'Transfer status: SUCCESS, FAILED, PENDING';


--
-- Name: COLUMN transfer_metrics.error_message; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.transfer_metrics.error_message IS 'Error message if transfer failed';


--
-- Name: COLUMN transfer_metrics.started_at; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.transfer_metrics.started_at IS 'When the transfer operation started';


--
-- Name: COLUMN transfer_metrics.completed_at; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON COLUMN metadata.transfer_metrics.completed_at IS 'When the transfer operation completed';


--
-- Name: transfer_metrics_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.transfer_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.transfer_metrics_id_seq OWNER TO "tomy.berrios";

--
-- Name: transfer_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.transfer_metrics_id_seq OWNED BY metadata.transfer_metrics.id;


--
-- Name: users; Type: TABLE; Schema: metadata; Owner: tomy.berrios
--

CREATE TABLE metadata.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    last_login timestamp without time zone,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'user'::character varying, 'viewer'::character varying])::text[])))
);


ALTER TABLE metadata.users OWNER TO "tomy.berrios";

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: metadata; Owner: tomy.berrios
--

CREATE SEQUENCE metadata.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE metadata.users_id_seq OWNER TO "tomy.berrios";

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: tomy.berrios
--

ALTER SEQUENCE metadata.users_id_seq OWNED BY metadata.users.id;


--
-- Name: alert_rules id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.alert_rules ALTER COLUMN id SET DEFAULT nextval('metadata.alert_rules_id_seq'::regclass);


--
-- Name: alerts id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.alerts ALTER COLUMN id SET DEFAULT nextval('metadata.alerts_id_seq'::regclass);


--
-- Name: api_catalog id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.api_catalog ALTER COLUMN id SET DEFAULT nextval('metadata.api_catalog_id_seq'::regclass);


--
-- Name: backup_control_log id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.backup_control_log ALTER COLUMN id SET DEFAULT nextval('metadata.backup_control_log_id_seq'::regclass);


--
-- Name: business_glossary id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.business_glossary ALTER COLUMN id SET DEFAULT nextval('metadata.business_glossary_id_seq'::regclass);


--
-- Name: column_catalog id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.column_catalog ALTER COLUMN id SET DEFAULT nextval('metadata.column_catalog_id_seq'::regclass);


--
-- Name: consent_management id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.consent_management ALTER COLUMN id SET DEFAULT nextval('metadata.consent_management_id_seq'::regclass);


--
-- Name: custom_jobs id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.custom_jobs ALTER COLUMN id SET DEFAULT nextval('metadata.custom_jobs_id_seq'::regclass);


--
-- Name: data_access_log id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_access_log ALTER COLUMN id SET DEFAULT nextval('metadata.data_access_log_id_seq'::regclass);


--
-- Name: data_dictionary id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_dictionary ALTER COLUMN id SET DEFAULT nextval('metadata.data_dictionary_id_seq'::regclass);


--
-- Name: data_governance_catalog id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog ALTER COLUMN id SET DEFAULT nextval('metadata.data_governance_catalog_id_seq'::regclass);


--
-- Name: data_governance_catalog_mariadb id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_mariadb ALTER COLUMN id SET DEFAULT nextval('metadata.data_governance_catalog_mariadb_id_seq'::regclass);


--
-- Name: data_governance_catalog_mongodb id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_mongodb ALTER COLUMN id SET DEFAULT nextval('metadata.data_governance_catalog_mongodb_id_seq'::regclass);


--
-- Name: data_governance_catalog_mssql id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_mssql ALTER COLUMN id SET DEFAULT nextval('metadata.data_governance_catalog_mssql_id_seq'::regclass);


--
-- Name: data_governance_catalog_oracle id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_oracle ALTER COLUMN id SET DEFAULT nextval('metadata.data_governance_catalog_oracle_id_seq'::regclass);


--
-- Name: data_quality id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_quality ALTER COLUMN id SET DEFAULT nextval('metadata.data_quality_id_seq'::regclass);


--
-- Name: data_quality_rules id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_quality_rules ALTER COLUMN id SET DEFAULT nextval('metadata.data_quality_rules_id_seq'::regclass);


--
-- Name: data_retention_jobs id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_retention_jobs ALTER COLUMN id SET DEFAULT nextval('metadata.data_retention_jobs_id_seq'::regclass);


--
-- Name: data_subject_requests id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_subject_requests ALTER COLUMN id SET DEFAULT nextval('metadata.data_subject_requests_id_seq'::regclass);


--
-- Name: job_results id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.job_results ALTER COLUMN id SET DEFAULT nextval('metadata.job_results_id_seq'::regclass);


--
-- Name: maintenance_control id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.maintenance_control ALTER COLUMN id SET DEFAULT nextval('metadata.maintenance_control_id_seq'::regclass);


--
-- Name: maintenance_metrics id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.maintenance_metrics ALTER COLUMN id SET DEFAULT nextval('metadata.maintenance_metrics_id_seq'::regclass);


--
-- Name: mdb_lineage id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.mdb_lineage ALTER COLUMN id SET DEFAULT nextval('metadata.mdb_lineage_id_seq'::regclass);


--
-- Name: mongo_lineage id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.mongo_lineage ALTER COLUMN id SET DEFAULT nextval('metadata.mongo_lineage_id_seq'::regclass);


--
-- Name: mssql_lineage id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.mssql_lineage ALTER COLUMN id SET DEFAULT nextval('metadata.mssql_lineage_id_seq'::regclass);


--
-- Name: oracle_lineage id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.oracle_lineage ALTER COLUMN id SET DEFAULT nextval('metadata.oracle_lineage_id_seq'::regclass);


--
-- Name: process_log id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.process_log ALTER COLUMN id SET DEFAULT nextval('metadata.process_log_id_seq'::regclass);


--
-- Name: processing_log id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.processing_log ALTER COLUMN id SET DEFAULT nextval('metadata.processing_log_id_seq'::regclass);


--
-- Name: query_performance id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.query_performance ALTER COLUMN id SET DEFAULT nextval('metadata.query_performance_id_seq'::regclass);


--
-- Name: system_logs id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.system_logs ALTER COLUMN id SET DEFAULT nextval('metadata.system_logs_id_seq'::regclass);


--
-- Name: transfer_metrics id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.transfer_metrics ALTER COLUMN id SET DEFAULT nextval('metadata.transfer_metrics_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.users ALTER COLUMN id SET DEFAULT nextval('metadata.users_id_seq'::regclass);


--
-- Name: alert_rules alert_rules_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.alert_rules
    ADD CONSTRAINT alert_rules_pkey PRIMARY KEY (id);


--
-- Name: alert_rules alert_rules_rule_name_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.alert_rules
    ADD CONSTRAINT alert_rules_rule_name_key UNIQUE (rule_name);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: api_catalog api_catalog_api_name_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.api_catalog
    ADD CONSTRAINT api_catalog_api_name_key UNIQUE (api_name);


--
-- Name: api_catalog api_catalog_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.api_catalog
    ADD CONSTRAINT api_catalog_pkey PRIMARY KEY (id);


--
-- Name: backup_control_log backup_control_log_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.backup_control_log
    ADD CONSTRAINT backup_control_log_pkey PRIMARY KEY (id);


--
-- Name: business_glossary business_glossary_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.business_glossary
    ADD CONSTRAINT business_glossary_pkey PRIMARY KEY (id);


--
-- Name: business_glossary business_glossary_term_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.business_glossary
    ADD CONSTRAINT business_glossary_term_key UNIQUE (term);


--
-- Name: catalog_locks catalog_locks_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.catalog_locks
    ADD CONSTRAINT catalog_locks_pkey PRIMARY KEY (lock_name);


--
-- Name: catalog catalog_new_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.catalog
    ADD CONSTRAINT catalog_new_pkey PRIMARY KEY (schema_name, table_name, db_engine);


--
-- Name: column_catalog column_catalog_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.column_catalog
    ADD CONSTRAINT column_catalog_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (key);


--
-- Name: consent_management consent_management_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.consent_management
    ADD CONSTRAINT consent_management_pkey PRIMARY KEY (id);


--
-- Name: consent_management consent_management_schema_name_table_name_data_subject_id_c_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.consent_management
    ADD CONSTRAINT consent_management_schema_name_table_name_data_subject_id_c_key UNIQUE (schema_name, table_name, data_subject_id, consent_type);


--
-- Name: custom_jobs custom_jobs_job_name_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.custom_jobs
    ADD CONSTRAINT custom_jobs_job_name_key UNIQUE (job_name);


--
-- Name: custom_jobs custom_jobs_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.custom_jobs
    ADD CONSTRAINT custom_jobs_pkey PRIMARY KEY (id);


--
-- Name: data_access_log data_access_log_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_access_log
    ADD CONSTRAINT data_access_log_pkey PRIMARY KEY (id);


--
-- Name: data_dictionary data_dictionary_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_dictionary
    ADD CONSTRAINT data_dictionary_pkey PRIMARY KEY (id);


--
-- Name: data_governance_catalog_mariadb data_governance_catalog_mariadb_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_mariadb
    ADD CONSTRAINT data_governance_catalog_mariadb_pkey PRIMARY KEY (id);


--
-- Name: data_governance_catalog_mongodb data_governance_catalog_mongodb_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_mongodb
    ADD CONSTRAINT data_governance_catalog_mongodb_pkey PRIMARY KEY (id);


--
-- Name: data_governance_catalog_mssql data_governance_catalog_mssql_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_mssql
    ADD CONSTRAINT data_governance_catalog_mssql_pkey PRIMARY KEY (id);


--
-- Name: data_governance_catalog_oracle data_governance_catalog_oracle_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_oracle
    ADD CONSTRAINT data_governance_catalog_oracle_pkey PRIMARY KEY (id);


--
-- Name: data_governance_catalog data_governance_catalog_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog
    ADD CONSTRAINT data_governance_catalog_pkey PRIMARY KEY (id);


--
-- Name: data_quality data_quality_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_quality
    ADD CONSTRAINT data_quality_pkey PRIMARY KEY (id);


--
-- Name: data_quality_rules data_quality_rules_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_quality_rules
    ADD CONSTRAINT data_quality_rules_pkey PRIMARY KEY (id);


--
-- Name: data_quality_rules data_quality_rules_rule_name_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_quality_rules
    ADD CONSTRAINT data_quality_rules_rule_name_key UNIQUE (rule_name);


--
-- Name: data_quality data_quality_table_check_unique; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_quality
    ADD CONSTRAINT data_quality_table_check_unique UNIQUE (schema_name, table_name, check_timestamp);


--
-- Name: data_retention_jobs data_retention_jobs_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_retention_jobs
    ADD CONSTRAINT data_retention_jobs_pkey PRIMARY KEY (id);


--
-- Name: data_subject_requests data_subject_requests_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_subject_requests
    ADD CONSTRAINT data_subject_requests_pkey PRIMARY KEY (id);


--
-- Name: data_subject_requests data_subject_requests_request_id_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_subject_requests
    ADD CONSTRAINT data_subject_requests_request_id_key UNIQUE (request_id);


--
-- Name: job_results job_results_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.job_results
    ADD CONSTRAINT job_results_pkey PRIMARY KEY (id);


--
-- Name: maintenance_control maintenance_control_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.maintenance_control
    ADD CONSTRAINT maintenance_control_pkey PRIMARY KEY (id);


--
-- Name: maintenance_control maintenance_control_unique; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.maintenance_control
    ADD CONSTRAINT maintenance_control_unique UNIQUE (db_engine, maintenance_type, schema_name, object_name, object_type);


--
-- Name: CONSTRAINT maintenance_control_unique ON maintenance_control; Type: COMMENT; Schema: metadata; Owner: tomy.berrios
--

COMMENT ON CONSTRAINT maintenance_control_unique ON metadata.maintenance_control IS 'Ensures uniqueness per database engine, allowing same object in different engines';


--
-- Name: maintenance_metrics maintenance_metrics_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.maintenance_metrics
    ADD CONSTRAINT maintenance_metrics_pkey PRIMARY KEY (id);


--
-- Name: mdb_lineage mdb_lineage_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.mdb_lineage
    ADD CONSTRAINT mdb_lineage_pkey PRIMARY KEY (id);


--
-- Name: mongo_lineage mongo_lineage_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.mongo_lineage
    ADD CONSTRAINT mongo_lineage_pkey PRIMARY KEY (id);


--
-- Name: mssql_lineage mssql_lineage_edge_key_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.mssql_lineage
    ADD CONSTRAINT mssql_lineage_edge_key_key UNIQUE (edge_key);


--
-- Name: mssql_lineage mssql_lineage_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.mssql_lineage
    ADD CONSTRAINT mssql_lineage_pkey PRIMARY KEY (id);


--
-- Name: oracle_lineage oracle_lineage_edge_key_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.oracle_lineage
    ADD CONSTRAINT oracle_lineage_edge_key_key UNIQUE (edge_key);


--
-- Name: oracle_lineage oracle_lineage_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.oracle_lineage
    ADD CONSTRAINT oracle_lineage_pkey PRIMARY KEY (id);


--
-- Name: process_log process_log_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.process_log
    ADD CONSTRAINT process_log_pkey PRIMARY KEY (id);


--
-- Name: processing_log processing_log_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.processing_log
    ADD CONSTRAINT processing_log_pkey PRIMARY KEY (id);


--
-- Name: query_performance query_performance_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.query_performance
    ADD CONSTRAINT query_performance_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: transfer_metrics transfer_metrics_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.transfer_metrics
    ADD CONSTRAINT transfer_metrics_pkey PRIMARY KEY (id);


--
-- Name: data_dictionary unique_dictionary_entry; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_dictionary
    ADD CONSTRAINT unique_dictionary_entry UNIQUE (schema_name, table_name, column_name);


--
-- Name: data_governance_catalog_mongodb unique_mongodb_governance; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_mongodb
    ADD CONSTRAINT unique_mongodb_governance UNIQUE (server_name, database_name, collection_name, index_name);


--
-- Name: data_governance_catalog_oracle unique_oracle_governance; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_oracle
    ADD CONSTRAINT unique_oracle_governance UNIQUE (server_name, schema_name, table_name, index_name);


--
-- Name: transfer_metrics unique_table_metrics; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.transfer_metrics
    ADD CONSTRAINT unique_table_metrics UNIQUE (schema_name, table_name, db_engine, created_date);


--
-- Name: data_governance_catalog unique_table_snapshot; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog
    ADD CONSTRAINT unique_table_snapshot UNIQUE (schema_name, table_name, snapshot_date);


--
-- Name: column_catalog uq_column_catalog; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.column_catalog
    ADD CONSTRAINT uq_column_catalog UNIQUE (schema_name, table_name, column_name, db_engine, connection_string);


--
-- Name: data_governance_catalog_mariadb uq_mariadb_object_snapshot; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_mariadb
    ADD CONSTRAINT uq_mariadb_object_snapshot UNIQUE (server_name, database_name, schema_name, table_name, index_name, snapshot_date);


--
-- Name: mdb_lineage uq_mdb_lineage_edge; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.mdb_lineage
    ADD CONSTRAINT uq_mdb_lineage_edge UNIQUE (edge_key);


--
-- Name: mongo_lineage uq_mongo_lineage_edge; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.mongo_lineage
    ADD CONSTRAINT uq_mongo_lineage_edge UNIQUE (edge_key);


--
-- Name: data_governance_catalog_mongodb uq_mongodb_object_snapshot; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_mongodb
    ADD CONSTRAINT uq_mongodb_object_snapshot UNIQUE (server_name, database_name, collection_name, index_name, snapshot_date);


--
-- Name: data_governance_catalog_mssql uq_mssql_object_unified; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.data_governance_catalog_mssql
    ADD CONSTRAINT uq_mssql_object_unified UNIQUE (server_name, database_name, schema_name, object_type, table_name, object_name, sp_name, index_id, object_id, snapshot_date);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: metadata; Owner: tomy.berrios
--

ALTER TABLE ONLY metadata.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_alert_rules_enabled; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_alert_rules_enabled ON metadata.alert_rules USING btree (enabled) WHERE (enabled = true);


--
-- Name: idx_alert_rules_type; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_alert_rules_type ON metadata.alert_rules USING btree (alert_type);


--
-- Name: idx_alerts_active; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_alerts_active ON metadata.alerts USING btree (status, severity) WHERE ((status)::text = 'OPEN'::text);


--
-- Name: idx_alerts_severity; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_alerts_severity ON metadata.alerts USING btree (severity);


--
-- Name: idx_alerts_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_alerts_status ON metadata.alerts USING btree (status);


--
-- Name: idx_alerts_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_alerts_table ON metadata.alerts USING btree (schema_name, table_name);


--
-- Name: idx_alerts_type; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_alerts_type ON metadata.alerts USING btree (alert_type);


--
-- Name: idx_api_catalog_active; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_api_catalog_active ON metadata.api_catalog USING btree (active);


--
-- Name: idx_api_catalog_name; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_api_catalog_name ON metadata.api_catalog USING btree (api_name);


--
-- Name: idx_api_catalog_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_api_catalog_status ON metadata.api_catalog USING btree (status);


--
-- Name: idx_api_catalog_target_engine; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_api_catalog_target_engine ON metadata.api_catalog USING btree (target_db_engine);


--
-- Name: idx_backup_control_database; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_backup_control_database ON metadata.backup_control_log USING btree (database_name);


--
-- Name: idx_backup_control_date; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_backup_control_date ON metadata.backup_control_log USING btree (backup_date);


--
-- Name: idx_backup_control_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_backup_control_status ON metadata.backup_control_log USING btree (backup_status);


--
-- Name: idx_catalog_active; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_catalog_active ON metadata.catalog USING btree (active);


--
-- Name: idx_catalog_db_engine; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_catalog_db_engine ON metadata.catalog USING btree (db_engine);


--
-- Name: idx_catalog_locks_expires; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_catalog_locks_expires ON metadata.catalog_locks USING btree (expires_at);


--
-- Name: idx_catalog_locks_name; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_catalog_locks_name ON metadata.catalog_locks USING btree (lock_name);


--
-- Name: idx_catalog_mongo_last_sync_time; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_catalog_mongo_last_sync_time ON metadata.catalog USING btree (mongo_last_sync_time) WHERE ((db_engine)::text = 'MongoDB'::text);


--
-- Name: idx_catalog_pk_strategy; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_catalog_pk_strategy ON metadata.catalog USING btree (pk_strategy);


--
-- Name: idx_catalog_schema_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_catalog_schema_table ON metadata.catalog USING btree (schema_name, table_name);


--
-- Name: idx_catalog_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_catalog_status ON metadata.catalog USING btree (status);


--
-- Name: idx_catalog_table_size; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_catalog_table_size ON metadata.catalog USING btree (table_size);


--
-- Name: idx_column_catalog_data_type; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_column_catalog_data_type ON metadata.column_catalog USING btree (data_type);


--
-- Name: idx_column_catalog_engine; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_column_catalog_engine ON metadata.column_catalog USING btree (db_engine);


--
-- Name: idx_column_catalog_pii; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_column_catalog_pii ON metadata.column_catalog USING btree (contains_pii) WHERE (contains_pii = true);


--
-- Name: idx_column_catalog_schema_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_column_catalog_schema_table ON metadata.column_catalog USING btree (schema_name, table_name);


--
-- Name: idx_column_catalog_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_column_catalog_table ON metadata.column_catalog USING btree (schema_name, table_name, db_engine);


--
-- Name: idx_consent_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_consent_status ON metadata.consent_management USING btree (consent_status);


--
-- Name: idx_consent_subject; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_consent_subject ON metadata.consent_management USING btree (data_subject_id);


--
-- Name: idx_consent_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_consent_table ON metadata.consent_management USING btree (schema_name, table_name);


--
-- Name: idx_custom_jobs_active; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_custom_jobs_active ON metadata.custom_jobs USING btree (active);


--
-- Name: idx_custom_jobs_enabled; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_custom_jobs_enabled ON metadata.custom_jobs USING btree (enabled);


--
-- Name: idx_custom_jobs_job_name; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_custom_jobs_job_name ON metadata.custom_jobs USING btree (job_name);


--
-- Name: idx_custom_jobs_schedule; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_custom_jobs_schedule ON metadata.custom_jobs USING btree (schedule_cron) WHERE (schedule_cron IS NOT NULL);


--
-- Name: idx_data_access_log_sensitive; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_access_log_sensitive ON metadata.data_access_log USING btree (is_sensitive_data) WHERE (is_sensitive_data = true);


--
-- Name: idx_data_access_log_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_access_log_table ON metadata.data_access_log USING btree (schema_name, table_name);


--
-- Name: idx_data_access_log_timestamp; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_access_log_timestamp ON metadata.data_access_log USING btree (access_timestamp);


--
-- Name: idx_data_access_log_user; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_access_log_user ON metadata.data_access_log USING btree (username);


--
-- Name: idx_data_governance_business_domain; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_governance_business_domain ON metadata.data_governance_catalog USING btree (business_domain);


--
-- Name: idx_data_governance_data_category; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_governance_data_category ON metadata.data_governance_catalog USING btree (data_category);


--
-- Name: idx_data_governance_health_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_governance_health_status ON metadata.data_governance_catalog USING btree (health_status);


--
-- Name: idx_data_governance_schema_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_governance_schema_table ON metadata.data_governance_catalog USING btree (schema_name, table_name);


--
-- Name: idx_data_governance_source_engine; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_governance_source_engine ON metadata.data_governance_catalog USING btree (inferred_source_engine);


--
-- Name: idx_data_quality_lookup; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_quality_lookup ON metadata.data_quality USING btree (schema_name, table_name, check_timestamp DESC);


--
-- Name: idx_data_quality_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_data_quality_status ON metadata.data_quality USING btree (validation_status);


--
-- Name: idx_dictionary_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_dictionary_table ON metadata.data_dictionary USING btree (schema_name, table_name);


--
-- Name: idx_dictionary_term; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_dictionary_term ON metadata.data_dictionary USING btree (glossary_term) WHERE (glossary_term IS NOT NULL);


--
-- Name: idx_dsar_email; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_dsar_email ON metadata.data_subject_requests USING btree (data_subject_email);


--
-- Name: idx_dsar_request_id; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_dsar_request_id ON metadata.data_subject_requests USING btree (request_id);


--
-- Name: idx_dsar_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_dsar_status ON metadata.data_subject_requests USING btree (request_status);


--
-- Name: idx_glossary_domain; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_glossary_domain ON metadata.business_glossary USING btree (business_domain);


--
-- Name: idx_glossary_term; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_glossary_term ON metadata.business_glossary USING btree (term);


--
-- Name: idx_governance_encryption; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_governance_encryption ON metadata.data_governance_catalog USING btree (encryption_at_rest) WHERE (encryption_at_rest = false);


--
-- Name: idx_governance_legal_hold; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_governance_legal_hold ON metadata.data_governance_catalog USING btree (legal_hold) WHERE (legal_hold = true);


--
-- Name: idx_governance_owner; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_governance_owner ON metadata.data_governance_catalog USING btree (data_owner);


--
-- Name: idx_governance_retention; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_governance_retention ON metadata.data_governance_catalog USING btree (retention_enforced, data_expiration_date) WHERE (retention_enforced = true);


--
-- Name: idx_governance_steward; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_governance_steward ON metadata.data_governance_catalog USING btree (data_steward);


--
-- Name: idx_job_results_created_at; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_job_results_created_at ON metadata.job_results USING btree (created_at);


--
-- Name: idx_job_results_job_name; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_job_results_job_name ON metadata.job_results USING btree (job_name);


--
-- Name: idx_job_results_process_log_id; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_job_results_process_log_id ON metadata.job_results USING btree (process_log_id);


--
-- Name: idx_maintenance_control_auto_execute; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_control_auto_execute ON metadata.maintenance_control USING btree (auto_execute, enabled, status);


--
-- Name: idx_maintenance_control_engine; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_control_engine ON metadata.maintenance_control USING btree (db_engine);


--
-- Name: idx_maintenance_control_impact; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_control_impact ON metadata.maintenance_control USING btree (impact_score DESC) WHERE ((status)::text = 'COMPLETED'::text);


--
-- Name: idx_maintenance_control_next_maintenance; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_control_next_maintenance ON metadata.maintenance_control USING btree (next_maintenance_date) WHERE ((status)::text = 'PENDING'::text);


--
-- Name: idx_maintenance_control_object; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_control_object ON metadata.maintenance_control USING btree (maintenance_type, schema_name, object_name, object_type);


--
-- Name: idx_maintenance_control_priority; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_control_priority ON metadata.maintenance_control USING btree (priority DESC, status) WHERE ((status)::text = ANY ((ARRAY['PENDING'::character varying, 'FAILED'::character varying])::text[]));


--
-- Name: idx_maintenance_control_server; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_control_server ON metadata.maintenance_control USING btree (server_name, database_name) WHERE (server_name IS NOT NULL);


--
-- Name: idx_maintenance_control_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_control_status ON metadata.maintenance_control USING btree (status, maintenance_type);


--
-- Name: idx_maintenance_metrics_date; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_metrics_date ON metadata.maintenance_metrics USING btree (execution_date DESC, maintenance_type);


--
-- Name: idx_maintenance_metrics_server; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_metrics_server ON metadata.maintenance_metrics USING btree (server_name, execution_date DESC) WHERE (server_name IS NOT NULL);


--
-- Name: idx_maintenance_metrics_type; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_maintenance_metrics_type ON metadata.maintenance_metrics USING btree (maintenance_type, execution_date DESC);


--
-- Name: idx_mariadb_catalog_db; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mariadb_catalog_db ON metadata.data_governance_catalog_mariadb USING btree (database_name);


--
-- Name: idx_mariadb_catalog_health; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mariadb_catalog_health ON metadata.data_governance_catalog_mariadb USING btree (health_status);


--
-- Name: idx_mariadb_catalog_snapshot_date; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mariadb_catalog_snapshot_date ON metadata.data_governance_catalog_mariadb USING btree (snapshot_date);


--
-- Name: idx_mdb_lineage_object; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mdb_lineage_object ON metadata.mdb_lineage USING btree (object_name, object_type);


--
-- Name: idx_mdb_lineage_server; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mdb_lineage_server ON metadata.mdb_lineage USING btree (server_name);


--
-- Name: idx_mdb_lineage_target; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mdb_lineage_target ON metadata.mdb_lineage USING btree (target_object_name, target_object_type);


--
-- Name: idx_mongo_lineage_object; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mongo_lineage_object ON metadata.mongo_lineage USING btree (object_name, object_type);


--
-- Name: idx_mongo_lineage_server; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mongo_lineage_server ON metadata.mongo_lineage USING btree (server_name);


--
-- Name: idx_mongo_lineage_server_db; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mongo_lineage_server_db ON metadata.mongo_lineage USING btree (server_name, database_name);


--
-- Name: idx_mongo_lineage_source; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mongo_lineage_source ON metadata.mongo_lineage USING btree (source_collection);


--
-- Name: idx_mongo_lineage_target; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mongo_lineage_target ON metadata.mongo_lineage USING btree (target_object_name, target_object_type);


--
-- Name: idx_mongodb_catalog_db; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mongodb_catalog_db ON metadata.data_governance_catalog_mongodb USING btree (database_name);


--
-- Name: idx_mongodb_catalog_health; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mongodb_catalog_health ON metadata.data_governance_catalog_mongodb USING btree (health_status);


--
-- Name: idx_mongodb_catalog_snapshot_date; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mongodb_catalog_snapshot_date ON metadata.data_governance_catalog_mongodb USING btree (snapshot_date);


--
-- Name: idx_mongodb_governance_health_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mongodb_governance_health_status ON metadata.data_governance_catalog_mongodb USING btree (health_status);


--
-- Name: idx_mongodb_governance_server_db_collection; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mongodb_governance_server_db_collection ON metadata.data_governance_catalog_mongodb USING btree (server_name, database_name, collection_name);


--
-- Name: idx_mssql_catalog_alert_level; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_catalog_alert_level ON metadata.data_governance_catalog_mssql USING btree (alert_level) WHERE (alert_level IS NOT NULL);


--
-- Name: idx_mssql_catalog_check_type; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_catalog_check_type ON metadata.data_governance_catalog_mssql USING btree (check_type) WHERE (check_type IS NOT NULL);


--
-- Name: idx_mssql_catalog_db; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_catalog_db ON metadata.data_governance_catalog_mssql USING btree (database_name);


--
-- Name: idx_mssql_catalog_health; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_catalog_health ON metadata.data_governance_catalog_mssql USING btree (health_status);


--
-- Name: idx_mssql_catalog_object_type; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_catalog_object_type ON metadata.data_governance_catalog_mssql USING btree (object_type);


--
-- Name: idx_mssql_catalog_snapshot_date; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_catalog_snapshot_date ON metadata.data_governance_catalog_mssql USING btree (snapshot_date);


--
-- Name: idx_mssql_catalog_sp_name; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_catalog_sp_name ON metadata.data_governance_catalog_mssql USING btree (sp_name) WHERE (sp_name IS NOT NULL);


--
-- Name: idx_mssql_catalog_table_snapshot; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_catalog_table_snapshot ON metadata.data_governance_catalog_mssql USING btree (server_name, database_name, schema_name, table_name, index_id, snapshot_date DESC);


--
-- Name: idx_mssql_lineage_object; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_lineage_object ON metadata.mssql_lineage USING btree (object_name, object_type);


--
-- Name: idx_mssql_lineage_server; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_lineage_server ON metadata.mssql_lineage USING btree (server_name);


--
-- Name: idx_mssql_lineage_target; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_mssql_lineage_target ON metadata.mssql_lineage USING btree (target_object_name, target_object_type);


--
-- Name: idx_oracle_gov_health; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_oracle_gov_health ON metadata.data_governance_catalog_oracle USING btree (health_status);


--
-- Name: idx_oracle_gov_server_schema; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_oracle_gov_server_schema ON metadata.data_governance_catalog_oracle USING btree (server_name, schema_name);


--
-- Name: idx_oracle_gov_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_oracle_gov_table ON metadata.data_governance_catalog_oracle USING btree (table_name);


--
-- Name: idx_oracle_lineage_object; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_oracle_lineage_object ON metadata.oracle_lineage USING btree (object_name);


--
-- Name: idx_oracle_lineage_server_schema; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_oracle_lineage_server_schema ON metadata.oracle_lineage USING btree (server_name, schema_name);


--
-- Name: idx_oracle_lineage_target; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_oracle_lineage_target ON metadata.oracle_lineage USING btree (target_object_name);


--
-- Name: idx_process_name; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_process_name ON metadata.process_log USING btree (process_name);


--
-- Name: idx_process_type; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_process_type ON metadata.process_log USING btree (process_type);


--
-- Name: idx_qp_blocking; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_qp_blocking ON metadata.query_performance USING btree (is_blocking) WHERE (is_blocking = true);


--
-- Name: idx_qp_captured; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_qp_captured ON metadata.query_performance USING btree (captured_at);


--
-- Name: idx_qp_category; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_qp_category ON metadata.query_performance USING btree (query_category);


--
-- Name: idx_qp_efficiency; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_qp_efficiency ON metadata.query_performance USING btree (query_efficiency_score);


--
-- Name: idx_qp_fingerprint; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_qp_fingerprint ON metadata.query_performance USING btree ("left"(query_fingerprint, 100));


--
-- Name: idx_qp_long_running; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_qp_long_running ON metadata.query_performance USING btree (is_long_running) WHERE (is_long_running = true);


--
-- Name: idx_qp_operation; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_qp_operation ON metadata.query_performance USING btree (operation_type);


--
-- Name: idx_qp_performance_tier; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_qp_performance_tier ON metadata.query_performance USING btree (performance_tier);


--
-- Name: idx_qp_source_type; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_qp_source_type ON metadata.query_performance USING btree (source_type);


--
-- Name: idx_quality_rules_enabled; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_quality_rules_enabled ON metadata.data_quality_rules USING btree (enabled) WHERE (enabled = true);


--
-- Name: idx_quality_rules_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_quality_rules_table ON metadata.data_quality_rules USING btree (schema_name, table_name);


--
-- Name: idx_retention_job_scheduled; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_retention_job_scheduled ON metadata.data_retention_jobs USING btree (scheduled_date) WHERE ((status)::text = 'PENDING'::text);


--
-- Name: idx_retention_job_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_retention_job_status ON metadata.data_retention_jobs USING btree (status);


--
-- Name: idx_retention_job_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_retention_job_table ON metadata.data_retention_jobs USING btree (schema_name, table_name);


--
-- Name: idx_source_schema; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_source_schema ON metadata.process_log USING btree (source_schema);


--
-- Name: idx_start_time; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_start_time ON metadata.process_log USING btree (start_time);


--
-- Name: idx_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_status ON metadata.process_log USING btree (status);


--
-- Name: idx_system_logs_created_at; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_system_logs_created_at ON metadata.system_logs USING btree (created_at DESC);


--
-- Name: idx_system_logs_timestamp; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_system_logs_timestamp ON metadata.system_logs USING btree ("timestamp" DESC);


--
-- Name: idx_target_schema; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_target_schema ON metadata.process_log USING btree (target_schema);


--
-- Name: idx_transfer_metrics_created_at; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_transfer_metrics_created_at ON metadata.transfer_metrics USING btree (created_at);


--
-- Name: idx_transfer_metrics_db_engine; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_transfer_metrics_db_engine ON metadata.transfer_metrics USING btree (db_engine);


--
-- Name: idx_transfer_metrics_schema_table; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_transfer_metrics_schema_table ON metadata.transfer_metrics USING btree (schema_name, table_name);


--
-- Name: idx_transfer_metrics_status; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_transfer_metrics_status ON metadata.transfer_metrics USING btree (status);


--
-- Name: idx_transfer_metrics_transfer_type; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_transfer_metrics_transfer_type ON metadata.transfer_metrics USING btree (transfer_type);


--
-- Name: idx_users_active; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_users_active ON metadata.users USING btree (active);


--
-- Name: idx_users_email; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_users_email ON metadata.users USING btree (email);


--
-- Name: idx_users_username; Type: INDEX; Schema: metadata; Owner: tomy.berrios
--

CREATE INDEX idx_users_username ON metadata.users USING btree (username);


--
-- Name: catalog catalog_processing_trigger; Type: TRIGGER; Schema: metadata; Owner: tomy.berrios
--

CREATE TRIGGER catalog_processing_trigger AFTER INSERT OR UPDATE ON metadata.catalog FOR EACH ROW EXECUTE FUNCTION metadata.track_processing_changes();


--
-- Name: catalog catalog_update_timestamp; Type: TRIGGER; Schema: metadata; Owner: tomy.berrios
--

CREATE TRIGGER catalog_update_timestamp BEFORE UPDATE ON metadata.catalog FOR EACH ROW EXECUTE FUNCTION metadata.update_catalog_timestamp();


--
-- Name: data_governance_catalog data_governance_update_timestamp; Type: TRIGGER; Schema: metadata; Owner: tomy.berrios
--

CREATE TRIGGER data_governance_update_timestamp BEFORE UPDATE ON metadata.data_governance_catalog FOR EACH ROW EXECUTE FUNCTION metadata.update_data_governance_timestamp();


--
-- Name: transfer_metrics transfer_metrics_update_timestamp; Type: TRIGGER; Schema: metadata; Owner: tomy.berrios
--

CREATE TRIGGER transfer_metrics_update_timestamp BEFORE INSERT ON metadata.transfer_metrics FOR EACH ROW EXECUTE FUNCTION metadata.update_transfer_metrics_timestamp();


--
-- Name: data_quality trigger_update_data_quality_timestamp; Type: TRIGGER; Schema: metadata; Owner: tomy.berrios
--

CREATE TRIGGER trigger_update_data_quality_timestamp BEFORE UPDATE ON metadata.data_quality FOR EACH ROW EXECUTE FUNCTION metadata.update_data_quality_timestamp();


--
-- PostgreSQL database dump complete
--

